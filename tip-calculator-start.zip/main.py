
print("Welcome to the tip calculator!")
bill_total = float(input("What was the total bill? $"))
tip_perc = float(input("What percentage tip would you like to give? 15, 18, or 20? "))
split = int(input("How many people are splitting the bill? "))
total = (bill_total * tip_perc * .01) + bill_total
split_total = round(total / split, 2)
print("Each person should pay: $" + str(split_total))